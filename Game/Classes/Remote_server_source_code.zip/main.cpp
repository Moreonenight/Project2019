#include <iostream>
#include <winsock2.h>
#include <thread>
#include "Server_remote.h"
#define TIMEOUT 5000
#define HERO_SIZE 1
#define COMMON_SIZE 40
#define DIFFERENCE_MAKEING 10
#include<ctime>
#include <fstream>
chat_socket::chat_socket(SOCKET& sockfd, struct sockaddr_in *addr)
:
    Socket(0),
    slisten(sockfd),
    remoteAddr(addr),
    nAddrlen(0)
{
    socket_accept();
}

socket_flag::socket_flag()
:
    turn_off_flag(false),
    is_receive_flag0(false),
    is_receive_flag1(false)
{
}

void chat_socket::socket_accept()
{
	nAddrlen=sizeof(*remoteAddr);
    Socket = accept(slisten, (SOCKADDR *)&remoteAddr, &nAddrlen);
    if(Socket == INVALID_SOCKET)
    {
        printf("Accept error! \n");
    }
}

SOCKADDR * chat_socket::get_remoteAddr()
{
    return (SOCKADDR *)&remoteAddr;
}


chat_socket_deque sockets;

void socket_client0(chat_socket_ptr _socket,char wclient[COMMON_SIZE],char rclient[COMMON_SIZE],std::shared_ptr<socket_flag> _flag)
{
    int timeout = TIMEOUT;
    setsockopt(_socket->Socket,SOL_SOCKET,SO_SNDTIMEO,(char *)&timeout,sizeof(timeout));
    while(_flag->turn_off_flag==false)
    {
        memset(wclient,0,COMMON_SIZE);
        if(_flag->turn_off_flag==true or recv(_socket->Socket, wclient , COMMON_SIZE, 0)<=0)
        {
            break;
        }
        _flag->is_receive_flag0=true;
        while(_flag->turn_off_flag==false and _flag->is_receive_flag1==false)
        {
            Sleep(1);
        }
        if(_flag->turn_off_flag==true or send(_socket->Socket, rclient, COMMON_SIZE, 0)<=0)
        {
            break;
        }
        _flag->is_receive_flag1=false;
    }
    _flag->turn_off_flag=true;
    closesocket(_socket->Socket);
}

void socket_client1(chat_socket_ptr _socket,char wclient[COMMON_SIZE],char rclient[COMMON_SIZE],std::shared_ptr<socket_flag> _flag)
{
    int timeout = TIMEOUT;
    setsockopt(_socket->Socket,SOL_SOCKET,SO_SNDTIMEO,(char *)&timeout,sizeof(timeout));
    while(_flag->turn_off_flag==false)
    {
        memset(wclient,0,COMMON_SIZE);
        if(_flag->turn_off_flag==true or recv(_socket->Socket, wclient , COMMON_SIZE, 0)<=0)
        {
            break;
        }
        _flag->is_receive_flag1=true;
        while(_flag->turn_off_flag==false and _flag->is_receive_flag0==false)
        {
            Sleep(1);
        }
        if(_flag->turn_off_flag==true or send(_socket->Socket, rclient, COMMON_SIZE, 0)<=0)
        {
            break;
        }
        _flag->is_receive_flag0=false;
    }
    _flag->turn_off_flag=true;
    closesocket(_socket->Socket);
}

void hero_client0(chat_socket_ptr _socket,char wclient[HERO_SIZE],char rclient[HERO_SIZE],bool& shall_shutdown,std::shared_ptr<socket_flag> _flag)
{
    memset(wclient,0,HERO_SIZE);
    if(_flag->turn_off_flag==true or recv(_socket->Socket, wclient , HERO_SIZE, 0)<=0)
    {
        closesocket(_socket->Socket);
        _flag->turn_off_flag=true;
        shall_shutdown=true;
        return;
    }
    _flag->is_receive_flag0=true;
    while(_flag->turn_off_flag==false and _flag->is_receive_flag1==false)
    {
        Sleep(1);
    }
    if(_flag->turn_off_flag==true or send(_socket->Socket, rclient, HERO_SIZE, 0)<=0)
    {
        closesocket(_socket->Socket);
        _flag->turn_off_flag=true;
        shall_shutdown=true;
        return;
    }
}

void hero_client1(chat_socket_ptr _socket,char wclient[HERO_SIZE],char rclient[HERO_SIZE],bool& shall_shutdown,std::shared_ptr<socket_flag> _flag)
{
    memset(wclient,0,HERO_SIZE);
    if(_flag->turn_off_flag==true or recv(_socket->Socket, wclient , HERO_SIZE, 0)<=0)
    {
        closesocket(_socket->Socket);
        _flag->turn_off_flag=true;
        return;
    }
    _flag->is_receive_flag1=true;
    wclient[0]+= DIFFERENCE_MAKEING;
    while(_flag->turn_off_flag==false and _flag->is_receive_flag0==false)
    {
        Sleep(1);
    }
    if(_flag->turn_off_flag==true or send(_socket->Socket, rclient, HERO_SIZE, 0)<=0)
    {
        closesocket(_socket->Socket);
        _flag->turn_off_flag=true;
        return;
    }
}

void gameroom(chat_socket_ptr socket0,chat_socket_ptr socket1)
{
    bool shall_shutdown = false;
    socket_flag _flag_;
    std::shared_ptr<socket_flag> _flag=std::make_shared <socket_flag>(_flag_);
    socket_flag nflag_;
    std::shared_ptr<socket_flag> _nflag=std::make_shared <socket_flag>(nflag_);
    char cclient0[COMMON_SIZE];
    char cclient1[COMMON_SIZE];
    char c0hero[HERO_SIZE];
    char c1hero[HERO_SIZE];
    std::thread h_client0(hero_client0,socket0,c0hero,c1hero,std::ref(shall_shutdown),_nflag);
    std::thread h_client1(hero_client1,socket1,c1hero,c0hero,std::ref(shall_shutdown),_nflag);
    h_client0.join();
    h_client1.join();
    if (shall_shutdown==true)
    {
        return;
    }
    std::thread _client0(socket_client0,socket0,cclient0,cclient1,_flag);
    std::thread _client1(socket_client1,socket1,cclient1,cclient0,_flag);
    _client0.join();
    _client1.join();
    closesocket(socket0->Socket);
    closesocket(socket1->Socket);
    return;
}

void listening_socket(SOCKET& slisten)
{
	if(slisten == INVALID_SOCKET)
	{
		printf("Accept error! \n");
		return;
	}
	if(listen(slisten, 5) == SOCKET_ERROR)
	{
		printf("Listen error! \n");
		return;
	}
	while(true)
	{
	    sockaddr_in* remoteAddr=new sockaddr_in;
		chat_socket _socket_(slisten, remoteAddr);
        chat_socket_ptr socket_ = std::make_shared <chat_socket>(_socket_);
        std::fstream server_log;
        server_log.open("./server_log.txt",std::ios::out | std::ios::app);
        char tmp[64];
        time_t t = time(0);
        strftime(tmp, sizeof(tmp), "%Y/%m/%d %X",localtime(&t) );
        server_log<<tmp<<"  ";
        server_log<<inet_ntoa(remoteAddr->sin_addr)<<std::endl;
		char tclient[100];
		memset(tclient,0,100);
        const char* WelcomeData = "Standing by to command offensive operations. Weapons free. Repeat, weapons free.\n";
        const char* ConfirmData ="Fleet action underway.\n";
        if(recv(socket_->Socket, tclient, strlen(WelcomeData)+1, 0)<=0)
        {
            closesocket(socket_->Socket);
            continue;
        }
        if(strcmp(tclient,WelcomeData)!=0)
        {
            closesocket(socket_->Socket);
            continue;
        }
        if(send(socket_->Socket, ConfirmData, strlen(ConfirmData)+1, 0)<=0)
        {
            closesocket(socket_->Socket);
            continue;
        }
		sockets.push_back(socket_);
		if (sockets.size()>=2)
		{
            if(send(sockets.at(0)->Socket, ConfirmData, strlen(ConfirmData)+1, 0)<=0)
            {
                closesocket(sockets.at(0)->Socket);
                sockets.pop_front();
                continue;
            }
            if(send(sockets.at(1)->Socket, ConfirmData, strlen(ConfirmData)+1, 0)<=0)
            {
                closesocket(sockets.at(1)->Socket);
                sockets.pop_front();
			    sockets.pop_front();
                continue;
            }
			std::thread gameroom_(gameroom,sockets.at(0),sockets.at(1));
			gameroom_.detach();
			sockets.pop_front();
			sockets.pop_front();
		}
	}
}

int main(int argc, char* argv[])
{
	if (argc !=2)
	{
	  std::cerr << "Usage: chat_server <port>\n";
	  return 1;
	}

	//Initialize WSA
    WORD sockVersion = MAKEWORD(2,2);
	WSADATA wsaData;
	if(WSAStartup(sockVersion, &wsaData)!=0)
	{
		return 0;
	}

	// Start Listening
	SOCKET slisten = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(slisten == INVALID_SOCKET)
	{
		printf("Socket error!\n");
		return 0;
	}
	sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_port = htons(atoi(argv[1]));
	sin.sin_addr.S_un.S_addr = INADDR_ANY;
	if(bind(slisten, (LPSOCKADDR)&sin, sizeof(sin)) == SOCKET_ERROR)
	{
		printf("Bind error!\n");
	}
	std::thread listening(listening_socket,std::ref(slisten));
	listening.detach();
	std::string str;
	while(std::getline(std::cin,str))
	{
		if(str=="shutdown")
		{
			break;
		}
	}
    return 0;
}
