#ifndef SERVER_REMOTE_H_INCLUDED
#define SERVER_REMOTE_H_INCLUDED
#include <deque>
#include <memory>
#include <string>
#include <mutex>


class chat_socket
{
public:
	SOCKET Socket;
	chat_socket(SOCKET& sockfd, struct sockaddr_in *addr);
	void socket_accept();
	SOCKADDR * get_remoteAddr();

private:
	SOCKET& slisten;
	sockaddr_in* remoteAddr;
	int nAddrlen;
};

typedef std::shared_ptr<chat_socket> chat_socket_ptr;
typedef std::deque<chat_socket_ptr> chat_socket_deque;

class socket_flag
{
public:
    socket_flag();
    bool turn_off_flag;
    bool is_receive_flag0;
    bool is_receive_flag1;
};

#endif // SERVER_REMOTE_H_INCLUDED
